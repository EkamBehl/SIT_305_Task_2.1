package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    //private Spinner spinner;
    private String option;
    private Double valueEntered;
    private TextView topRight;
    private TextView midRight;
    private TextView bottomRight;
    private TextView midLeft;
    private TextView bottomLeft;
    private TextView topLeft;

    private static  final DecimalFormat form= new DecimalFormat("0.00");
    private EditText enteredText;
    private ImageButton buttonMetres,buttonKgs,buttonCelsius;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enteredText=findViewById(R.id.enterText);
        topLeft=findViewById(R.id.topL);

        buttonMetres=findViewById(R.id.Button);
        buttonCelsius=findViewById(R.id.Button3);
        buttonKgs=findViewById(R.id.Button2);
        topRight=findViewById(R.id.topR);
        midLeft=findViewById(R.id.midL);
        midRight=findViewById(R.id.midR);
        bottomLeft=findViewById(R.id.bottomL);
        bottomRight=findViewById(R.id.bottomR);


        List<String> type = Arrays.asList("Metres","Celsius","Kilograms");
        final Spinner spinner =findViewById(R.id.spinner1);

        ArrayAdapter adapter= new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,type);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //optionVal=spinner.getSelectedItem().toString();
        spinner.setOnItemSelectedListener(this);

        buttonMetres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=enteredText.getText().toString();
                valueEntered=Double.parseDouble(s);
                String state=spinner.getSelectedItem().toString();
                if(Objects.equals(state, "Metres")){
                    metres();
                }else{
                    Toast.makeText(getApplicationContext(),"Please Select Meters",Toast.LENGTH_LONG).show();
                }
            }
        });
        buttonKgs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=enteredText.getText().toString();
                valueEntered=Double.parseDouble(s);
                String state=spinner.getSelectedItem().toString();
                if(Objects.equals(state, "Kilograms")){
                    kgConvert();
                }else{
                    Toast.makeText(getApplicationContext(),"Please Select Kilogram",Toast.LENGTH_LONG).show();
                }


            }
        });
        buttonCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=enteredText.getText().toString();
                valueEntered=Double.parseDouble(s);
                String state=spinner.getSelectedItem().toString();
                if(Objects.equals(state, "Celsius")){
                    celsiusConvert();
                }else{
                    Toast.makeText(getApplicationContext(),"Please Select Celsius",Toast.LENGTH_LONG).show();
                }
            }
        });




    }

    public void celsiusConvert() {
        //For Fahrenheit:


        Double fahrenheit = (valueEntered * 9 / 5) + 32.00;
        String farh=form.format(fahrenheit);
        topLeft.setText(farh);
        topRight.setText("Fahrenheit");

        //For Kelvin:
        Double kelvin = valueEntered + 273.15;
        String kelv= form.format(kelvin);
        midLeft.setText(kelv);
        midRight.setText("Kelvin");

        bottomLeft.setText("");
        bottomRight.setText("");

        Toast.makeText(getApplicationContext(),option,Toast.LENGTH_LONG).show();


    }

    public void kgConvert()
    {


        //For Grams
        Double grams=(valueEntered*1000.00);
        String gr= form.format(grams);
        topLeft.setText(gr);
        topRight.setText("grams");

        //For Ounce:
        Double ounce=(valueEntered*35.27);
        String oz= form.format(ounce);
        midLeft.setText(oz);
        midRight.setText("Ounce(oz)");
        //For Pounds:
        Double pounds=valueEntered*2.205;
        String pnds= form.format(pounds);
        bottomLeft.setText(pnds);
        bottomRight.setText("Pounds");




    }

    public void metres(){

        //For Centimeters
        Double result=valueEntered*100.00;
        String cms= form.format(result);
        topLeft.setText(cms);
        topRight.setText("Centimetres");

        //For Foot
        Double foot=valueEntered*3.281;
        String feet= form.format(foot);
        midLeft.setText(feet);
        midRight.setText("Foot");

        //For Inches
        Double inches=valueEntered*39.37;
        String inc= form.format(inches);
        bottomLeft.setText(inc);
        bottomRight.setText("Inches");


    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        option=adapterView.getItemAtPosition(i).toString();
        Toast.makeText(getApplicationContext(),option,Toast.LENGTH_LONG).show();

    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

}